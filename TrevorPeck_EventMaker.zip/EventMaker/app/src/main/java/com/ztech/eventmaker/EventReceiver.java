package com.ztech.eventmaker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class EventReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        new NotificationHelper(context, "Event time", "Get ready. There are only 15 minutes left in event.");
    }

}
