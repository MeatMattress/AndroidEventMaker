package com.ztech.eventmaker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddEvent extends AppCompatActivity {

    private EditText titleEdit, descEdit;
    private CardView dateEdit, timeEdit;
    private Button addEvent;
    TextView date, time;
    private Event event;
    Calendar selected;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        initViews();
        setOnClickListeners();

    }

    private void setOnClickListeners() {

        dateEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDateDialog();
            }
        });

        timeEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimeDialog();
            }
        });

        findViewById(R.id.backBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String title = titleEdit.getText().toString();
                String description = descEdit.getText().toString();
                String dateA = date.getText().toString();
                String timeA = time.getText().toString();

                if(dateA.equals("Enter event date"))
                {
                    Toast.makeText(AddEvent.this, "Date is required", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(timeA.equals("Enter event time"))
                {
                    Toast.makeText(AddEvent.this, "Time is required", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(title.isEmpty())
                {
                    titleEdit.setError("Title is required");
                    titleEdit.requestFocus();
                    return;
                }

                if(description.isEmpty())
                {
                    descEdit.setError("Description is required");
                    descEdit.requestFocus();
                    return;
                }

                String finalTime = dateA + " at " + timeA;


                selected.add(Calendar.MINUTE, -15);
                setAlert(selected);

                if(addEvent.getText().equals("Update"))
                {
                    new DBHelper(AddEvent.this).updateEvent(event.getTime(), title, description, finalTime);
                    Toast.makeText(AddEvent.this, "Event updated!", Toast.LENGTH_SHORT).show();
                    finish();
                }else
                {

                    Calendar calendar = Calendar.getInstance();

                    new DBHelper(AddEvent.this).insertEvent(String.valueOf(calendar.getTimeInMillis()), title,description,finalTime);

                    Toast.makeText(AddEvent.this, "Event Added!", Toast.LENGTH_SHORT).show();

                    titleEdit.setText("");
                    descEdit.setText("");
                    date.setText("Enter event time");

                }

            }
        });
    }

    private void setAlert(Calendar calendar) {
        Intent intent = new Intent(this, EventReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this.getApplicationContext(), 234324243, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
        Toast.makeText(this, "Alert set!",Toast.LENGTH_LONG).show();
    }

    private void showTimeDialog() {

        int hour = selected.get(Calendar.HOUR_OF_DAY);
        int min = selected.get(Calendar.MINUTE);
        TimePickerDialog dialog = new TimePickerDialog(AddEvent.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hr, int mn) {

                Log.d("GTR", hr + " " + mn);

                selected.set(Calendar.MINUTE, mn);
                selected.set(Calendar.HOUR_OF_DAY, (hr-1));

                time.setText(hr + ":" + mn);

            }
        }, hour, min, true);

        dialog.show();
    }

    private void showDateDialog() {

        int year = selected.get(Calendar.YEAR);
        int month = selected.get(Calendar.MONTH);
        int day = selected.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int y, int m, int d) {

                Log.d("GTR", y + "_" + m + "_" + d);
                selected.set(y,m,d);

                date.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selected.getTime()));

            }
        }, year, month, day);

        dialog.show();

    }

    private void initViews() {
        titleEdit = findViewById(R.id.titleEdit);
        descEdit = findViewById(R.id.descEdit);
        dateEdit = findViewById(R.id.dateEdit);
        addEvent = findViewById(R.id.addEventBtn);
        date = findViewById(R.id.date);
        timeEdit = findViewById(R.id.timeEdit);
        time = findViewById(R.id.time);
        selected = Calendar.getInstance();

        if(getIntent().hasExtra("title"))
        {
            event = new Event(
                    getIntent().getStringExtra("title"),
                    getIntent().getStringExtra("date"),
                    getIntent().getStringExtra("description"),
                    getIntent().getStringExtra("time"));

            String[] timeS = event.getDate().split("at");


            titleEdit.setText(event.getTitle());
            descEdit.setText(event.getDesc());
            date.setText(timeS[0].trim());
            time.setText(timeS[1].trim());

            addEvent.setText("Update");

        }

    }
}