package com.ztech.eventmaker;

public interface ItemClickListener {

    public void onItemEdit();
    public void onItemDeleted();

}
