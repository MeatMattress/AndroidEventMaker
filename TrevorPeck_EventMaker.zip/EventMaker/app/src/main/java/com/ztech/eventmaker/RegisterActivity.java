package com.ztech.eventmaker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText emailEdit, passwordEdit, confirmPasswordEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        initViews();


        findViewById(R.id.registerBtn).setOnClickListener(view -> {

            String email = emailEdit.getText().toString();
            String password = passwordEdit.getText().toString();
            String confirm = confirmPasswordEdit.getText().toString();

            if(email.isEmpty())
            {
                emailEdit.setError("Email is required");
                emailEdit.requestFocus();
                return;
            }

            if(password.isEmpty())
            {
                emailEdit.setError("Password is required");
                emailEdit.requestFocus();
                return;
            }

            if(!password.equals(confirm))
            {
                Toast.makeText(RegisterActivity.this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
                return;
            }

            new DBHelper(RegisterActivity.this).insertUser(email, password);

            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });
    }

    private void initViews() {
        emailEdit = findViewById(R.id.emailEdit);
        passwordEdit = findViewById(R.id.passwordEdit);
        confirmPasswordEdit = findViewById(R.id.cPasswordEdit);
    }
}