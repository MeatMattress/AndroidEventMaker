package com.ztech.eventmaker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String EVENTS_TABLE_NAME = "events";
    private HashMap hp;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table events " +
                        "(time text, title text,description text, timeToDisplay text)"
        );

        db.execSQL("create table users(email text, password text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS events");
        onCreate(db);
    }

    public boolean insertUser(String email, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password", password);
        db.insert("users", null, contentValues);
        return true;
    }


    public boolean checkPassword(String email, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from users where email='" + email + "'", null );

        Log.d("HGT", res.isAfterLast() + "");

        res.moveToFirst();

        while(!res.isAfterLast())
        {
            String pass = res.getString(res.getColumnIndex("password"));

            if(password.equals(pass))
            {
                return true;
            }else
            {
                return false;
            }
        }

        return false;
    }


    public boolean insertEvent (String time, String title, String description, String timeToDisplay) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("time", time);
        contentValues.put("title", title);
        contentValues.put("description", description);
        contentValues.put("timeToDisplay", timeToDisplay);
        db.insert("events", null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from events where id="+id+"", null );
        return res;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, EVENTS_TABLE_NAME);
        return numRows;
    }

    public boolean updateEvent (String time, String title, String description, String timeToDisplay) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("time", time);
        contentValues.put("title", title);
        contentValues.put("description", description);
        contentValues.put("timeToDisplay", timeToDisplay);
        db.update("events", contentValues, "time = ? ", new String[]{time});
        return true;
    }

    public Integer deleteEvent (String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("events",
                "time = ? ",
                new String[] { time });
    }

    public ArrayList<Event> getAllEvents() {
        ArrayList<Event> array_list = new ArrayList<>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from events", null );
        res.moveToFirst();

        while(!res.isAfterLast()){

            array_list.add(new Event(
                    res.getString(res.getColumnIndex("title")),
                    res.getString(res.getColumnIndex("timeToDisplay")),
                    res.getString(res.getColumnIndex("description")),
                    res.getString(res.getColumnIndex("time"))
            ));
            res.moveToNext();
        }
        return array_list;
    }
}
