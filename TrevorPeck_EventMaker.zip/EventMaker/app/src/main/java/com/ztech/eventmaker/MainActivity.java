package com.ztech.eventmaker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_SMS = 100;
    private RecyclerView eventList;
    private TextView noEvents;

    @Override
    protected void onResume() {
        super.onResume();

        if(eventList != null)
        {
            setAdapter();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkPermissions();
        initViews();


        findViewById(R.id.addBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddEvent.class);
                startActivity(intent);
            }
        });

    }

    private void checkPermissions() {

        int readPermission = ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_SMS);

        if(readPermission != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.READ_SMS},
                    REQUEST_SMS
            );
        }

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == REQUEST_SMS)
        {
            boolean notGranted = false;

            for (int grantResult : grantResults) {
                if (grantResult == PackageManager.PERMISSION_DENIED) {
                    notGranted = true;
                    break;
                }
            }

            if(!notGranted)
            {
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
            }else
            {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void initViews() {
        eventList = findViewById(R.id.eventList);
        eventList.setLayoutManager(new LinearLayoutManager(this));
        eventList.setHasFixedSize(true);
        noEvents = findViewById(R.id.noEvents);

        setAdapter();

    }

    private void setAdapter() {
        ArrayList<Event> events;

        events = new DBHelper(this).getAllEvents();

        if(events.isEmpty())
        {
            noEvents.setVisibility(View.VISIBLE);
            eventList.setVisibility(View.GONE);
        }else
        {
            noEvents.setVisibility(View.GONE);
            eventList.setVisibility(View.VISIBLE);
            eventList.setAdapter(new EventAdapter(this, events, new ItemClickListener() {
                @Override
                public void onItemEdit() {

                }

                @Override
                public void onItemDeleted() {
                    setAdapter();
                }
            }));
        }

//        events.add(new Event("Title: Title of Some Event","Date: 2-Feb-2020 at 6 PM","Description: Here is the description of the item you can explore the description here as i write some dummy text."));
//        events.add(new Event("Title: Title of Some Event","Date: 2-Feb-2020 at 6 PM","Description: Here is the description of the item you can explore the description here as i write some dummy text."));
//        events.add(new Event("Title: Title of Some Event","Date: 2-Feb-2020 at 6 PM","Description: Here is the description of the item you can explore the description here as i write some dummy text."));
//        events.add(new Event("Title: Title of Some Event","Date: 2-Feb-2020 at 6 PM","Description: Here is the description of the item you can explore the description here as i write some dummy text."));
//        events.add(new Event("Title: Title of Some Event","Date: 2-Feb-2020 at 6 PM","Description: Here is the description of the item you can explore the description here as i write some dummy text."));
//        events.add(new Event("Title: Title of Some Event","Date: 2-Feb-2020 at 6 PM","Description: Here is the description of the item you can explore the description here as i write some dummy text."));
//        events.add(new Event("Title: Title of Some Event","Date: 2-Feb-2020 at 6 PM","Description: Here is the description of the item you can explore the description here as i write some dummy text."));


    }
}