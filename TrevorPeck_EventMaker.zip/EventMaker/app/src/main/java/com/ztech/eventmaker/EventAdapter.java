package com.ztech.eventmaker;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventAdapter extends RecyclerView.Adapter<EventViewHolder>{

    private Context context;
    private ArrayList<Event> events;
    int pos = 0;
    private ItemClickListener itemListener;

    private PopupMenu.OnMenuItemClickListener listener = new PopupMenu.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {

            int id = menuItem.getItemId();

            switch (id)
            {
                case R.id.editEvent:
                    Intent intent = new Intent(context, AddEvent.class);
                    intent.putExtra("title", events.get(pos).getTitle());
                    intent.putExtra("description", events.get(pos).getDesc());
                    intent.putExtra("date", events.get(pos).getDate());
                    intent.putExtra("time", events.get(pos).getTime());
                    context.startActivity(intent);
                    break;

                case R.id.deleteEvent:
                    new DBHelper(context).deleteEvent(events.get(pos).getTime());
                    itemListener.onItemDeleted();
                    break;
            }

            return true;
        }
    };

    public EventAdapter(Context context, ArrayList<Event> events, ItemClickListener itemListener) {
        this.context = context;
        this.events = events;
        this.itemListener = itemListener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        holder.eventTitle.setText(events.get(position).getTitle());
        holder.eventDesc.setText(events.get(position).getDesc());
        holder.eventDate.setText(events.get(position).getDate());
        holder.menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                pos = position;

                PopupMenu popup = new PopupMenu(context, view);
                popup.setOnMenuItemClickListener(listener);
                popup.inflate(R.menu.item_menu);
                popup.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }
}

class EventViewHolder extends RecyclerView.ViewHolder{

    TextView eventTitle, eventDate, eventDesc;
    ImageView menuBtn;

    public EventViewHolder(@NonNull View itemView) {
        super(itemView);
        eventDate = itemView.findViewById(R.id.eventDate);
        eventTitle = itemView.findViewById(R.id.eventTitle);
        eventDesc = itemView.findViewById(R.id.eventDesc);
        menuBtn = itemView.findViewById(R.id.menuBtn);
    }
}
